from django.apps import AppConfig


class NouappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nouapp'
